package ui.dialog;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import construction.IncludeExamplesCheckBoxPanel;
import construction.OpenBrowsePanel;
import construction.OperationsComboBoxPanel;
import construction.PortsComboBoxPanel;
import construction.RequiredContentCheckBox;
import construction.SaveBrowsePanel;
import construction.ServicesRadioButtonPanel;

public class GUIDialog {

	private JFrame frame;
    // in constructor imi dau datele pentru a crea frame ul ce apare la rulare 
	public GUIDialog() {

		frame = new JFrame("OpenAPI Checker");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(600, 400);
	}
   // in aceasta metoda execut afisarea Dialogului
	public void execute() {
		// aici adaug elementele create in clasele alaturate in frame
		addComponentsToPane(frame.getContentPane());
		
		//creez cele 2 butoane din stanga jos ca un panel unitar. Butonul cancel inchide dialogul cand e apasat.
		JButton cancelButton = new JButton("Cancel");
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				System.exit(0);
				}
		});
		
		
		JButton sendButton = new JButton("Send");
		JPanel buttonPane = new JPanel();
		
		buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.LINE_AXIS));
		buttonPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
		buttonPane.add(Box.createHorizontalGlue());
		buttonPane.add(sendButton);
		buttonPane.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPane.add(cancelButton);

        frame.add(buttonPane);
		frame.setVisible(true);
	}
	
   // metoda care introduce elementele de dialog in container. Nu am gasit inca o alta metoda pentru a afisa elementele
   // componente ale frame mai estetic 
	// toate obiectele ce sunt introduse in container au o interfata comuna, Panel, care apeleaza metoda createPanel
	// ce transforma atat labelul specific cat si butonul sau butoanele intr un panel unitar
	private void addComponentsToPane(Container contentPane) {
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));
		//  butonul de OpenApi care introduce URL-ul fisierului jason in casuta de text.  
		OpenBrowsePanel openBrowsePanel = new OpenBrowsePanel("OpenAPI URL: ", 30, "Browse",frame);
		JPanel firstPanel = openBrowsePanel.createPanel();
		firstPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(firstPanel);
		// butonul ce formeaza elementele de tip radioButton
		ServicesRadioButtonPanel servicesRadioButtonPanel = new ServicesRadioButtonPanel("Services: ", "Currency", "Test");
		JPanel secondPanel = servicesRadioButtonPanel.createPanel();
		secondPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(secondPanel);
		//butonul ce formeaza primul comboBox. am preferat sa am in clase diferite cele 2 combobox-uri pentru ca m-am gandit
		//ca butoanele vor implementa functii diferite
		String[] stringComboBox1= { "soap1", "soap2"};
        PortsComboBoxPanel portsComboBoxPanel = new PortsComboBoxPanel("Ports: ", stringComboBox1);
        JPanel thirdPanel = portsComboBoxPanel.createPanel();
        thirdPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(thirdPanel);
		// cel de al doile combobox
		String[] stringComboBox2 = {"getRealTime","getTime","getTimeAsString"};
        OperationsComboBoxPanel comboBoxPanel2 = new OperationsComboBoxPanel("Operations: ", stringComboBox2);
        JPanel forthPanel = comboBoxPanel2.createPanel();
        forthPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(forthPanel);
		//primul check box
		RequiredContentCheckBox requiredContentCheckBox = new RequiredContentCheckBox("Only required content");
        JPanel fifthpanel = requiredContentCheckBox.createPanel();
        fifthpanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(fifthpanel);
		//al doilea checkbox
		IncludeExamplesCheckBoxPanel includeExamplesCheckBoxPanel = new IncludeExamplesCheckBoxPanel("Include Examples");
        JPanel sixthpanel = includeExamplesCheckBoxPanel.createPanel();
        sixthpanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(sixthpanel);
		//botonul de browse care va afisa numele fisierului in care vom salva fisierul
		SaveBrowsePanel saveBrowsePanel = new SaveBrowsePanel("Output File:  ", 30, "Browse",frame);
		JPanel seventhPanel = saveBrowsePanel.createPanel();
		seventhPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
		contentPane.add(seventhPanel);
	}

	public static void main(String[] args) {
		GUIDialog gui = new GUIDialog();
		gui.execute();

	}

}
