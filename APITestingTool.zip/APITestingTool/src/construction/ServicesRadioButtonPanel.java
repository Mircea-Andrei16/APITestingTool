package construction;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
//clasa ce formeaza radiobuttons
public class ServicesRadioButtonPanel implements Panel {

	private String labelName;
	private String firstRadioButtonName;
	private String secondRadioButtonName;
	private JPanel panel;
	
	public ServicesRadioButtonPanel(String labelName, String firstRadioButtonName, String secondRadioButtonName) {
		super();
		this.labelName = labelName;
		this.firstRadioButtonName = firstRadioButtonName;
		this.secondRadioButtonName = secondRadioButtonName;
	}
	
	public JPanel createPanel() {
		
		panel = new JPanel();
		
		JLabel serviceLabel = new JLabel(labelName);
		JRadioButton currecyButton = new JRadioButton(firstRadioButtonName);
		JRadioButton testButton = new JRadioButton(secondRadioButtonName);

		currecyButton.setBounds(75, 50, 100, 30);
		testButton.setBounds(75, 50, 100, 30);

		ButtonGroup buttonGroup = new ButtonGroup();
		buttonGroup.add(currecyButton);
		buttonGroup.add(testButton);
		
		panel.add(serviceLabel);
		panel.add(currecyButton);
		panel.add(testButton);
		
		return panel;
	}
	
	
	

}
