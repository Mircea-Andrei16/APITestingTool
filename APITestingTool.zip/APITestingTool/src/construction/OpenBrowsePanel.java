package construction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.net.MalformedURLException;
import java.net.URL;

//clasa primeste ca paramterii numele labelului ,numarul de elemente maxime ce pot aparea in texfile,numele butonului si
// frame care il folosesc pentru a forma JFileChooser-ul
public class OpenBrowsePanel implements Panel {

	private String label;
	private int textLength;
	private String button;
	private JPanel panel;
	private JFrame frame;

	public OpenBrowsePanel(String label, int textLength, String button, JFrame frame) {
		super();
		this.label = label;
		this.textLength = textLength;
		this.button = button;
		this.frame = frame;
	
	
	
	}

	@Override
	public JPanel createPanel() {

		panel = new JPanel();

		JLabel openAPILabel = new JLabel(label);
		JTextField textField = new JTextField(textLength);

		JButton browseButton = new JButton(button);
//cand buronul este apasat aprare casuta ce ne lasa sa cautam pe disk fisiere .json
		browseButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				// la inceput apare directorul c
				JFileChooser fileChooser = new JFileChooser(new File("C:/"));
				FileTypeFilter docFilter = new FileTypeFilter(".json", "JSON Files");
				fileChooser.addChoosableFileFilter(docFilter);
				fileChooser.setDialogTitle("Select Location");
				fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
				fileChooser.setAcceptAllFileFilterUsed(false);
				if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
					//am folosit metoda try and catch pentru a gasi url. din rulari mi am dat seama ca url afisat
					//este identic cu elementul gasit prin metoda .getPath(). am crezut ca trebuie sa mi afiseze 
					//un encoded url , probabil am inteles eu gresit.
					try {
						@SuppressWarnings("deprecation")
						URL fileURL = fileChooser.getSelectedFile().toURL();
						String fileOut = fileURL.toString();
						textField.setText(fileOut);
						
					} catch (MalformedURLException e) {
						e.printStackTrace();
					}
				}
			}
		});

		panel.add(openAPILabel);
		panel.add(textField);
		panel.add(browseButton);

		return panel;
	}

}
