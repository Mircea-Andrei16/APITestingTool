package construction;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
//clasa specifica pentru unul dintre check boxuri
//primeste ca parametru un string ce-l transforma in numele checkbox-ului
public class RequiredContentCheckBox implements Panel {

	private String checkBoxName;
	private JPanel panel;

	public RequiredContentCheckBox(String checkBoxName) {
		super();
		this.checkBoxName = checkBoxName;
	}

	public JPanel createPanel() {
		
		panel = new JPanel();
		
		JCheckBox checkBox = new JCheckBox(checkBoxName);  
        checkBox.setBounds(100,100, 50,50);  
        
        panel.add(checkBox);
        
		return panel;
	}

}
