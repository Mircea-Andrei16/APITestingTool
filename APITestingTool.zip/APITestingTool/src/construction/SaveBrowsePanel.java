package construction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
// clasa ce formeza butonul de save. primeste aceiasi parametrii ca si primul buton
// butoanele doar pun in casuta text url-ul si respectiv numele fisiserului de output, inca nu fac nimic concret
public class SaveBrowsePanel implements Panel {

	private String label;
	private int textLength;
	private String button;
	private JPanel panel;
	private JFrame frame;

	public SaveBrowsePanel(String label, int textLength, String button, JFrame frame) {
		this.label = label;
		this.textLength = textLength;
		this.button = button;
		this.frame = frame;
	
	
	
	}
	@Override
	public JPanel createPanel() {
		panel = new JPanel();

		JLabel openAPILabel = new JLabel(label);
		JTextField textField = new JTextField(textLength);

		JButton browseButton = new JButton(button);

		browseButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent evt) {
				JFileChooser fileChooser = new JFileChooser(new File("C:/"));
				FileTypeFilter docFilter = new FileTypeFilter(".json", "JSON Files");
				fileChooser.addChoosableFileFilter(docFilter);
				fileChooser.setDialogTitle("Select Location");
				fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				fileChooser.setAcceptAllFileFilterUsed(true);
				if (fileChooser.showSaveDialog(frame) == JFileChooser.APPROVE_OPTION) {
					String fileID = fileChooser.getSelectedFile().getName();
					textField.setText(fileID);
				}
			}
		});

		panel.add(openAPILabel);
		panel.add(textField);
		panel.add(browseButton);

		return panel;
	}

}
