package construction;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
//clasa ce formeza un combobox. primeste numele label-ului si un vectori de stringuri pentru a forma combobox-ul
public class PortsComboBoxPanel implements Panel {

	private String labelName;
	private String[] comboBoxElements;
	private JPanel panel;
	
	public PortsComboBoxPanel(String labelName, String[] comboBoxElements) {
		super();
		this.labelName = labelName;
		this.comboBoxElements = comboBoxElements;
	}
	
	public JPanel createPanel() {
		
		panel  = new JPanel();
		
		JLabel portLabel = new JLabel(labelName);
		JComboBox comboBox1 = new JComboBox(comboBoxElements);
		
		panel.add(portLabel);
		panel.add(comboBox1);
		
		return panel;
	}

}
