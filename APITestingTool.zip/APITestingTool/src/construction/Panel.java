package construction;

import javax.swing.JPanel;

public interface Panel {
	
	JPanel createPanel();

}
