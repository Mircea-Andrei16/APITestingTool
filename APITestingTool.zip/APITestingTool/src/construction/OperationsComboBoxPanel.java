package construction;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
//clasa ce formeza un combobox. primeste numele label-ului si un vectori de stringuri pentru a forma combobox-ul
public class OperationsComboBoxPanel implements Panel {
	
	private String labelName;
	private String[] comboBoxElements;
	private JPanel panel;
	
	public OperationsComboBoxPanel(String labelName, String[] comboBoxElements) {
		super();
		this.labelName = labelName;
		this.comboBoxElements = comboBoxElements;
	}
	
	@Override
	public JPanel createPanel() {
		
		panel  = new JPanel();
		
		JLabel portLabel = new JLabel(labelName);
		JComboBox comboBox1 = new JComboBox(comboBoxElements);
		
		panel.add(portLabel);
		panel.add(comboBox1);
		
		return panel;
	}

}
